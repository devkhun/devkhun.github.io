var store = [{
        "title": "Git .gitignore 적용하기",
        "excerpt":"Git .gitignore 적용하기 root 디렉토리에 .gitignore 파일 생성 후 형상관리가 되면 안되는 파일들 기입 # git cache 삭제 $ git rm -r --cached . $ git add . $ git commit -m \"cache clear\" 또는 아래와 같이 git 추적금지를 시킬 수 있음 git update-index --assume-unchanged git update-index --no-assume-unchanged git rm...","categories": ["git_basic"],
        "tags": ["git"],
        "url": "/git_basic/git-gitignore-%EC%A0%81%EC%9A%A9%ED%95%98%EA%B8%B0/",
        "teaser": null
      },{
        "title": "Git remote url 확인하기",
        "excerpt":"Git remote url 확인하기  $ git remote -v  ","categories": ["git_basic"],
        "tags": ["git"],
        "url": "/git_basic/git-remote-url-%ED%99%95%EC%9D%B8%ED%95%98%EA%B8%B0/",
        "teaser": null
      },{
        "title": "Git 연동하기",
        "excerpt":"Git 연동하기     git clone 받은 후   clone 받은 디렉토리 이동 후 아래 명령어 실행     $ git init $ git add README.md $ git commit -m \"first commit\" $ git remote add origin [GIT URL] $ git push -u origin main           로컬환경에 git이 설치되어있는 경우에 위 명령어 실행 가능  ","categories": ["git_basic"],
        "tags": ["git"],
        "url": "/git_basic/git-%EC%97%B0%EB%8F%99%ED%95%98%EA%B8%B0/",
        "teaser": null
      },{
        "title": "카프카란 무엇일까?",
        "excerpt":"실무에서 아파치카프카를 사용하여 대량의 이벤트를 처리하고 있다. 대~강 대용량 데이터를 처리하기 위한 큐 정도로만 알고 있었는데 실제로 사용해보니 개념을 정확하게 알아야 카프카를 100% 활용할 수 있을거라고 생각했다. 카프카란 ? 정식 명칭은 아파치카프카(Apache Kafka) 분산형 스트리밍 플랫폼 대량의 데이터를 안정적이고 실시간으로 처리할 수 있도록 설계 한마디로 성능과 기능이 좋은 큐(Queue) 발행-구독...","categories": ["kafka_basic"],
        "tags": ["kafka"],
        "url": "/kafka_basic/%EC%B9%B4%ED%94%84%EC%B9%B4%EB%9E%80-%EB%AC%B4%EC%97%87%EC%9D%BC%EA%B9%8C/",
        "teaser": null
      },{
        "title": "카프카의 주요 개념 및 용어",
        "excerpt":"주요 개념 및 용어 KafkaCluster 카프카의 브로커(broker)들의 모임 =&gt; 확장성과 고가용성을 위해서 borker들이 클러스터로 구성 보통 3개 이상으로 구성하는 것을 권장한다고 한다 설정은 어떻게..? 하는거지? =&gt; 찾아보니 설정 파일로 조정하는게 아니라 실제로 추가하거나 제거하는 작업을 해야한다고 함! 어렵구먼 Broker 각각의 카프카 서버 Zookeeper 카프카 클러스터 정보 및 분산처리 관리 등...","categories": ["kafka_basic"],
        "tags": ["kafka"],
        "url": "/kafka_basic/%EC%B9%B4%ED%94%84%EC%B9%B4-%EA%B0%9C%EB%85%90-%EB%B0%8F-%EC%9A%A9%EC%96%B4/",
        "teaser": null
      }]
