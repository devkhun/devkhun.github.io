---
title: "Git remote url 확인하기"
categories:
  - git_basic 
tags:
  - git
toc: true
toc_sticky: true
---

### Git remote url 확인하기
```
$ git remote -v
```
